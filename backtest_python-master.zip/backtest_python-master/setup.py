from distutils.core import setup

setup(name='fmz',
      version='1.2',
      description='FMZ local backtest',
      author='Zero',
      author_email='hi@fmz.com',
      url='https://www.fmz.com/',
      packages=[""]
     )
